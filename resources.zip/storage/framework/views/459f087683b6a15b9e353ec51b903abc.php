<!DOCTYPE html>
<html lang="id">
<?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="section-with-background d-flex flex-column min-vh-100">
    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="three-lines-spinner">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
    </div>

    <!-- Sidebar & Top Navbar Component -->
    <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content Yield Area -->
    <main class="main-body flex-grow-1">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer Component -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Page Scripts Hook -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script>
        window.addEventListener("load", function() {
            const overlay = document.getElementById("loadingOverlay");
            if (overlay) {
                overlay.style.opacity = '0';
                overlay.style.transition = 'opacity 0.25s ease';
                setTimeout(function() {
                    overlay.style.display = "none";
                }, 250);
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\Sicana 350\Documents\Project\laravel11\resources\views/layouts/app.blade.php ENDPATH**/ ?>